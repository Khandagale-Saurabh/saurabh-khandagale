package puzzle8;

public enum DIRECTIONS {
	LEFT,RIGHT,UP,DOWN
}
