package puzzle8;

public interface Search {

	public boolean search(); //search interface to help with UI when creating a Search.
}
