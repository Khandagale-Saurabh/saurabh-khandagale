Instructions :

1. Clone repo and go to folder
2. Go to root directory i.e. Mongo-Booking from terminal, run npm install to install all the node_modules
3. then , run node server/server.js

-Used Mongodb, Nodejs, express, bootstrap, Operating System: MacO High Sierra

-Steps to install mongodb on mac: https://docs.mongodb.com/manual/tutorial/install-mongodb-on-os-x/

Make sure to update the following variable in Mongo-Booking/server/server.js file

	var rootDir = '/Users/vipulsrivastav/Desktop/Mongo-Booking/';

![Screenshot software](https://github.com/credo92/Mongo-Booking/blob/master/pic.png "screenshot")	